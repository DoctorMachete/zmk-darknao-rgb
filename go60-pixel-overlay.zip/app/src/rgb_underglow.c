/*
 * Copyright (c) 2020 The ZMK Contributors
 *
 * SPDX-License-Identifier: MIT
 */

#include <zephyr/device.h>
#include <zephyr/init.h>
#include <zephyr/kernel.h>
#include <zephyr/settings/settings.h>

#include <math.h>
#include <stdlib.h>

#include <zmk/battery.h>
#include <zmk/ble.h>
#include <zmk/endpoints.h>
#include <zmk/keymap.h>
#include <zmk/matrix.h>
#include <zmk/behavior.h>

#include <zmk/hid_indicators.h>
#include <zmk/usb.h>

#include <zephyr/logging/log.h>

#include <zephyr/drivers/led_strip.h>
#include <drivers/ext_power.h>
#include <drivers/behavior.h>

#include <zmk/rgb_underglow.h>
#include <zmk/rgb_underglow_layer.h>

#include <zmk/activity.h>
#include <zmk/event_manager.h>
#include <zmk/events/activity_state_changed.h>
#include <zmk/events/usb_conn_state_changed.h>
#include <zmk/events/underglow_color_changed.h>

#include <zmk/workqueue.h>
#include <zmk/events/split_peripheral_layer_changed.h>

#if IS_ENABLED(CONFIG_ZMK_SPLIT_BLE_CENTRAL_BATTERY_LEVEL_FETCHING)
#include <zmk/split/central.h>
#endif

#if !IS_ENABLED(CONFIG_ZMK_SPLIT_ROLE_CENTRAL)
#include <zmk/split/peripheral_layers.h>
#endif

LOG_MODULE_DECLARE(zmk, CONFIG_ZMK_LOG_LEVEL);

#if !DT_HAS_CHOSEN(zmk_underglow)

#error "A zmk,underglow chosen node must be declared"

#endif

#define STRIP_CHOSEN DT_CHOSEN(zmk_underglow)
#define STRIP_NUM_PIXELS DT_PROP(STRIP_CHOSEN, chain_length)

#if DT_HAS_COMPAT_STATUS_OKAY(zmk_underglow_layer) && IS_ENABLED(CONFIG_EXPERIMENTAL_RGB_LAYER)
#define UNDERGLOW_LAYER_ENABLED 1
static void zmk_rgb_underglow_set_layer(uint8_t layer, bool wakeup);
#endif

#define HUE_MAX 360
#define SAT_MAX 100
#define BRT_MAX 100

BUILD_ASSERT(CONFIG_ZMK_RGB_UNDERGLOW_BRT_MIN <= CONFIG_ZMK_RGB_UNDERGLOW_BRT_MAX,
             "ERROR: RGB underglow maximum brightness is less than minimum brightness");

enum rgb_underglow_effect {
    UNDERGLOW_EFFECT_SOLID,
    UNDERGLOW_EFFECT_BREATHE,
    UNDERGLOW_EFFECT_SPECTRUM,
    UNDERGLOW_EFFECT_SWIRL,
#if IS_ENABLED(UNDERGLOW_LAYER_ENABLED)
    UNDERGLOW_EFFECT_LAYER_INDICATORS,
#endif
    UNDERGLOW_EFFECT_NUMBER // Used to track number of underglow effects
};

struct rgb_underglow_state {
    struct zmk_led_hsb color;
    uint8_t animation_speed;
    uint8_t current_effect;
    uint16_t animation_step;
    bool on;
    bool status_active;
    bool layer_enabled;
    uint16_t status_animation_step;
};

static const struct device *led_strip;

static struct led_rgb pixels[STRIP_NUM_PIXELS];
static struct led_rgb status_pixels[STRIP_NUM_PIXELS];

// Persistent per-pixel override layer (set via &pixel behavior). Drawn on top
// of underglow + indicators, survives underglow on/off, cleared explicitly.
static struct led_rgb pixel_overrides[STRIP_NUM_PIXELS];
static bool pixel_override_active[STRIP_NUM_PIXELS];
static bool any_pixel_override;

// Persistent, relocatable status indicators (battery block + USB output).
// Unlike the fixed-color overrides above, these recompute their colors live on
// every status refresh, so they track the current battery level / USB state.
// They are author-placed (positions come from the keymap) and persist across
// underglow on/off until explicitly disabled.
#define PERSIST_BAT_MAX_PIXELS 8
static struct {
    bool active;
    uint8_t count;
    uint8_t positions[PERSIST_BAT_MAX_PIXELS];
} persist_battery;

static struct {
    bool active;
    uint8_t position;
} persist_usb;

static inline bool any_persist_indicator(void) {
    return persist_battery.active || persist_usb.active;
}

static struct rgb_underglow_state state;

#if IS_ENABLED(CONFIG_ZMK_RGB_UNDERGLOW_EXT_POWER)
static const struct device *const ext_power = DEVICE_DT_GET(DT_INST(0, zmk_ext_power_generic));
#endif

void zmk_rgb_set_ext_power(void);

static struct zmk_led_hsb hsb_scale_min_max(struct zmk_led_hsb hsb) {
    hsb.b = CONFIG_ZMK_RGB_UNDERGLOW_BRT_MIN +
            (CONFIG_ZMK_RGB_UNDERGLOW_BRT_MAX - CONFIG_ZMK_RGB_UNDERGLOW_BRT_MIN) * hsb.b / BRT_MAX;
    return hsb;
}

static struct zmk_led_hsb hsb_scale_zero_max(struct zmk_led_hsb hsb) {
    hsb.b = hsb.b * CONFIG_ZMK_RGB_UNDERGLOW_BRT_MAX / BRT_MAX;
    return hsb;
}

static struct led_rgb hsb_to_rgb(struct zmk_led_hsb hsb) {
    float r = 0, g = 0, b = 0;

    uint8_t i = hsb.h / 60;
    float v = hsb.b / ((float)BRT_MAX);
    float s = hsb.s / ((float)SAT_MAX);
    float f = hsb.h / ((float)HUE_MAX) * 6 - i;
    float p = v * (1 - s);
    float q = v * (1 - f * s);
    float t = v * (1 - (1 - f) * s);

    switch (i % 6) {
    case 0:
        r = v;
        g = t;
        b = p;
        break;
    case 1:
        r = q;
        g = v;
        b = p;
        break;
    case 2:
        r = p;
        g = v;
        b = t;
        break;
    case 3:
        r = p;
        g = q;
        b = v;
        break;
    case 4:
        r = t;
        g = p;
        b = v;
        break;
    case 5:
        r = v;
        g = p;
        b = q;
        break;
    }

    struct led_rgb rgb = {r : r * 255, g : g * 255, b : b * 255};

    return rgb;
}

static void zmk_rgb_underglow_effect_solid(void) {
    for (int i = 0; i < STRIP_NUM_PIXELS; i++) {
        pixels[i] = hsb_to_rgb(hsb_scale_min_max(state.color));
    }
}

static void zmk_rgb_underglow_effect_breathe(void) {
    for (int i = 0; i < STRIP_NUM_PIXELS; i++) {
        struct zmk_led_hsb hsb = state.color;
        hsb.b = abs(state.animation_step - 1200) / 12;

        pixels[i] = hsb_to_rgb(hsb_scale_zero_max(hsb));
    }

    state.animation_step += state.animation_speed * 10;

    if (state.animation_step > 2400) {
        state.animation_step = 0;
    }
}

static void zmk_rgb_underglow_effect_spectrum(void) {
    for (int i = 0; i < STRIP_NUM_PIXELS; i++) {
        struct zmk_led_hsb hsb = state.color;
        hsb.h = state.animation_step;

        pixels[i] = hsb_to_rgb(hsb_scale_min_max(hsb));
    }

    state.animation_step += state.animation_speed;
    state.animation_step = state.animation_step % HUE_MAX;
}

static void zmk_rgb_underglow_effect_swirl(void) {
    for (int i = 0; i < STRIP_NUM_PIXELS; i++) {
        struct zmk_led_hsb hsb = state.color;
        hsb.h = (HUE_MAX / STRIP_NUM_PIXELS * i + state.animation_step) % HUE_MAX;

        pixels[i] = hsb_to_rgb(hsb_scale_min_max(hsb));
    }

    state.animation_step += state.animation_speed * 2;
    state.animation_step = state.animation_step % HUE_MAX;
}

#if IS_ENABLED(UNDERGLOW_LAYER_ENABLED)
static void zmk_rgb_underglow_effect_layer(void) {
    bool active = false;
    for (int i = 0; i < STRIP_NUM_PIXELS; i++) {
        pixels[i].r -= state.animation_speed < pixels[i].r ? state.animation_speed : pixels[i].r;
        pixels[i].g -= state.animation_speed < pixels[i].g ? state.animation_speed : pixels[i].g;
        pixels[i].b -= state.animation_speed < pixels[i].b ? state.animation_speed : pixels[i].b;
        if (pixels[i].r || pixels[i].g || pixels[i].b) {
            active = true;
        }
    }
    state.animation_step += state.animation_speed;

    if (state.animation_step > 255 || !active) {
        zmk_rgb_underglow_transient_off();
    }
}
#endif // IS_ENABLED(UNDERGLOW_LAYER_ENABLED)

static int zmk_led_generate_status(void);

static void zmk_led_write_pixels(void) {
    static struct led_rgb led_buffer[STRIP_NUM_PIXELS];
    int bat0;
    int blend = 0;
    int reset_ext_power = 0;

#if IS_ENABLED(CONFIG_ZMK_BATTERY_REPORTING)
    bat0 = zmk_battery_state_of_charge();
#else
    bat0 = 100;
#endif

    if (state.status_active || any_pixel_override || any_persist_indicator()) {
        blend = zmk_led_generate_status();
    }

    // fast path: no status indicators, battery level OK
    if (blend == 0 && bat0 >= 20) {
        led_strip_update_rgb(led_strip, pixels, STRIP_NUM_PIXELS);
        return;
    }
    // battery below minimum charge
    if (bat0 < 10) {
        memset(pixels, 0, sizeof(struct led_rgb) * STRIP_NUM_PIXELS);
        if (state.on) {
            int c_power = ext_power_get(ext_power);
            if (c_power && !state.status_active) {
                // power is on, RGB underglow is on, but battery is too low
                state.on = false;
                reset_ext_power = true;
            }
        }
    }

    if (blend == 0) {
        for (int i = 0; i < STRIP_NUM_PIXELS; i++) {
            led_buffer[i] = pixels[i];
        }
    } else if (blend >= 256) {
        for (int i = 0; i < STRIP_NUM_PIXELS; i++) {
            led_buffer[i] = status_pixels[i];
        }
    } else if (blend < 256) {
        uint16_t blend_l = blend;
        uint16_t blend_r = 256 - blend;
        for (int i = 0; i < STRIP_NUM_PIXELS; i++) {
            led_buffer[i].r =
                ((status_pixels[i].r * blend_l) >> 8) + ((pixels[i].r * blend_r) >> 8);
            led_buffer[i].g =
                ((status_pixels[i].g * blend_l) >> 8) + ((pixels[i].g * blend_r) >> 8);
            led_buffer[i].b =
                ((status_pixels[i].b * blend_l) >> 8) + ((pixels[i].b * blend_r) >> 8);
        }
    }

    // battery below 20%, reduce LED brightness
    if (bat0 < 20) {
        for (int i = 0; i < STRIP_NUM_PIXELS; i++) {
            led_buffer[i].r = led_buffer[i].r >> 1;
            led_buffer[i].g = led_buffer[i].g >> 1;
            led_buffer[i].b = led_buffer[i].b >> 1;
        }
    }

    int err = led_strip_update_rgb(led_strip, led_buffer, STRIP_NUM_PIXELS);
    if (err < 0) {
        LOG_ERR("Failed to update the RGB strip (%d)", err);
    }

    if (reset_ext_power) {
        zmk_rgb_set_ext_power();
    }
}

#define UNDERGLOW_INDICATORS DT_PATH(underglow_indicators)

#if defined(DT_N_S_underglow_indicators_EXISTS)
#define UNDERGLOW_INDICATORS_ENABLED 1
#else
#define UNDERGLOW_INDICATORS_ENABLED 0
#endif

#if !UNDERGLOW_INDICATORS_ENABLED
static int zmk_led_generate_indicators(void) { return 0; }
#else

const uint8_t underglow_layer_state[] = DT_PROP(UNDERGLOW_INDICATORS, layer_state);
const uint8_t underglow_ble_state[] = DT_PROP(UNDERGLOW_INDICATORS, ble_state);
const uint8_t underglow_bat_lhs[] = DT_PROP(UNDERGLOW_INDICATORS, bat_lhs);
const uint8_t underglow_bat_rhs[] = DT_PROP(UNDERGLOW_INDICATORS, bat_rhs);

#define HEXRGB(R, G, B)                                                                            \
    ((struct led_rgb){                                                                             \
        r : (CONFIG_ZMK_RGB_UNDERGLOW_BRT_MAX * (R)) / 0xff,                                       \
        g : (CONFIG_ZMK_RGB_UNDERGLOW_BRT_MAX * (G)) / 0xff,                                       \
        b : (CONFIG_ZMK_RGB_UNDERGLOW_BRT_MAX * (B)) / 0xff                                        \
    })
const struct led_rgb red = HEXRGB(0xff, 0x00, 0x00);
const struct led_rgb yellow = HEXRGB(0xff, 0xff, 0x00);
const struct led_rgb green = HEXRGB(0x00, 0xff, 0x00);
const struct led_rgb dull_green = HEXRGB(0x00, 0xff, 0x68);
const struct led_rgb magenta = HEXRGB(0xff, 0x00, 0xff);
const struct led_rgb white = HEXRGB(0xff, 0xff, 0xff);
const struct led_rgb lilac = HEXRGB(0x6b, 0x1f, 0xce);

static void zmk_led_battery_level(int bat_level, const uint8_t *addresses, size_t addresses_len) {
    struct led_rgb bat_colour;

    if (bat_level > 40) {
        bat_colour = green;
    } else if (bat_level > 20) {
        bat_colour = yellow;
    } else {
        bat_colour = red;
    }

    // originally, six levels, 0 .. 100

    for (int i = 0; i < addresses_len; i++) {
        int min_level = (i * 100) / (addresses_len - 1);
        if (bat_level >= min_level) {
            status_pixels[addresses[i]] = bat_colour;
        }
    }
}

static void zmk_led_fill(struct led_rgb color, const uint8_t *addresses, size_t addresses_len) {
    for (int i = 0; i < addresses_len; i++) {
        status_pixels[addresses[i]] = color;
    }
}

#define ZMK_LED_NUMLOCK_BIT BIT(0)
#define ZMK_LED_CAPSLOCK_BIT BIT(1)
#define ZMK_LED_SCROLLLOCK_BIT BIT(2)

static int zmk_led_generate_indicators(void) {
    for (int i = 0; i < STRIP_NUM_PIXELS; i++) {
        status_pixels[i] = (struct led_rgb){r : 0, g : 0, b : 0};
    }

    // BATTERY STATUS
#if IS_ENABLED(CONFIG_ZMK_BATTERY_REPORTING)
    zmk_led_battery_level(zmk_battery_state_of_charge(), underglow_bat_lhs,
                          DT_PROP_LEN(UNDERGLOW_INDICATORS, bat_lhs));
#if IS_ENABLED(CONFIG_ZMK_SPLIT_BLE_CENTRAL_BATTERY_LEVEL_FETCHING)
    uint8_t peripheral_level = 0;
    int rc = zmk_split_central_get_peripheral_battery_level(0, &peripheral_level);

    if (rc == 0) {
        zmk_led_battery_level(peripheral_level, underglow_bat_rhs,
                              DT_PROP_LEN(UNDERGLOW_INDICATORS, bat_rhs));
    } else if (rc == -ENOTCONN) {
        zmk_led_fill(red, underglow_bat_rhs, DT_PROP_LEN(UNDERGLOW_INDICATORS, bat_rhs));
    } else if (rc == -EINVAL) {
        LOG_ERR("Invalid peripheral index requested for battery level read: 0");
    }
#endif // CONFIG_ZMK_SPLIT_BLE_CENTRAL_BATTERY_LEVEL_FETCHING
#endif // CONFIG_ZMK_BATTERY_REPORTING

    // CAPSLOCK/NUMLOCK/SCROLLOCK STATUS
    zmk_hid_indicators_t led_flags = zmk_hid_indicators_get_current_profile();

    if (led_flags & ZMK_LED_CAPSLOCK_BIT)
        status_pixels[DT_PROP(UNDERGLOW_INDICATORS, capslock)] = red;
    if (led_flags & ZMK_LED_NUMLOCK_BIT)
        status_pixels[DT_PROP(UNDERGLOW_INDICATORS, numlock)] = red;
    if (led_flags & ZMK_LED_SCROLLLOCK_BIT)
        status_pixels[DT_PROP(UNDERGLOW_INDICATORS, scrolllock)] = red;

    // LAYER STATUS
    for (uint8_t i = 0; i < DT_PROP_LEN(UNDERGLOW_INDICATORS, layer_state); i++) {
        if (zmk_keymap_layer_active(i))
            status_pixels[underglow_layer_state[i]] = magenta;
    }

    struct zmk_endpoint_instance active_endpoint = zmk_endpoints_selected();

    if (!zmk_endpoints_preferred_transport_is_active())
        status_pixels[DT_PROP(UNDERGLOW_INDICATORS, output_fallback)] = red;

#if IS_ENABLED(CONFIG_ZMK_BLE)
    int active_ble_profile_index = zmk_ble_active_profile_index();
    for (uint8_t i = 0;
         i < MIN(ZMK_BLE_PROFILE_COUNT, DT_PROP_LEN(UNDERGLOW_INDICATORS, ble_state)); i++) {
        int8_t status = zmk_ble_profile_status(i);
        int ble_pixel = underglow_ble_state[i];
        if (status == 2 && active_endpoint.transport == ZMK_TRANSPORT_BLE &&
            active_ble_profile_index == i) { // connected AND active
            status_pixels[ble_pixel] = white;
        } else if (status == 2) { // connected
            status_pixels[ble_pixel] = dull_green;
        } else if (status == 1) { // paired
            status_pixels[ble_pixel] = red;
        } else if (status == 0) { // unused
            status_pixels[ble_pixel] = lilac;
        }
    }
#endif

    enum zmk_usb_conn_state usb_state = zmk_usb_get_conn_state();
    if (usb_state == ZMK_USB_CONN_HID &&
        active_endpoint.transport == ZMK_TRANSPORT_USB) { // connected AND active
        status_pixels[DT_PROP(UNDERGLOW_INDICATORS, usb_state)] = white;
    } else if (usb_state == ZMK_USB_CONN_HID) { // connected
        status_pixels[DT_PROP(UNDERGLOW_INDICATORS, usb_state)] = dull_green;
    } else if (usb_state == ZMK_USB_CONN_POWERED) { // powered
        status_pixels[DT_PROP(UNDERGLOW_INDICATORS, usb_state)] = red;
    } else if (usb_state == ZMK_USB_CONN_NONE) { // disconnected
        status_pixels[DT_PROP(UNDERGLOW_INDICATORS, usb_state)] = lilac;
    }

    int16_t blend = 256;
    if (state.status_animation_step < (500 / 25)) {
        blend = ((state.status_animation_step * 256) / (500 / 25));
    } else if (state.status_animation_step > (8000 / 25)) {
        blend = 256 - (((state.status_animation_step - (8000 / 25)) * 256) / (2000 / 25));
    }
    if (blend < 0)
        blend = 0;
    if (blend > 256)
        blend = 256;

    return blend;
}
#endif // underglow_indicators exists

// Self-contained colors for the persistent indicators, so they work even on
// boards without an underglow-indicators node (where the constants above are
// not compiled). Same RGB values and brightness scaling as the indicators.
#define PERSIST_RGB(R, G, B)                                                                        \
    ((struct led_rgb){                                                                              \
        r : (CONFIG_ZMK_RGB_UNDERGLOW_BRT_MAX * (R)) / 0xff,                                        \
        g : (CONFIG_ZMK_RGB_UNDERGLOW_BRT_MAX * (G)) / 0xff,                                        \
        b : (CONFIG_ZMK_RGB_UNDERGLOW_BRT_MAX * (B)) / 0xff                                         \
    })

static void persist_paint_battery(void) {
#if IS_ENABLED(CONFIG_ZMK_BATTERY_REPORTING)
    if (!persist_battery.active || persist_battery.count == 0)
        return;

    int bat_level = zmk_battery_state_of_charge();

    struct led_rgb bat_colour;
    if (bat_level > 40) {
        bat_colour = PERSIST_RGB(0x00, 0xff, 0x00); // green
    } else if (bat_level > 20) {
        bat_colour = PERSIST_RGB(0xff, 0xff, 0x00); // yellow
    } else {
        bat_colour = PERSIST_RGB(0xff, 0x00, 0x00); // red
    }

    int n = persist_battery.count;
    for (int i = 0; i < n; i++) {
        uint8_t pos = persist_battery.positions[i];
        if (pos >= STRIP_NUM_PIXELS)
            continue;
        // Light this segment if the charge reaches its threshold. With n
        // segments the thresholds are evenly spread 0..100 (segment 0 always
        // lights, the last needs 100%).
        int min_level = (n > 1) ? (i * 100) / (n - 1) : 0;
        if (bat_level >= min_level) {
            status_pixels[pos] = bat_colour;
        }
    }
#endif // CONFIG_ZMK_BATTERY_REPORTING
}

static void persist_paint_usb(void) {
    if (!persist_usb.active || persist_usb.position >= STRIP_NUM_PIXELS)
        return;

    struct zmk_endpoint_instance active_endpoint = zmk_endpoints_selected();
    enum zmk_usb_conn_state usb_state = zmk_usb_get_conn_state();

    if (usb_state == ZMK_USB_CONN_HID && active_endpoint.transport == ZMK_TRANSPORT_USB) {
        status_pixels[persist_usb.position] = PERSIST_RGB(0xff, 0xff, 0xff); // connected + active: white
    } else if (usb_state == ZMK_USB_CONN_HID) {
        status_pixels[persist_usb.position] = PERSIST_RGB(0x00, 0xff, 0x68); // connected: dull green
    } else if (usb_state == ZMK_USB_CONN_POWERED) {
        status_pixels[persist_usb.position] = PERSIST_RGB(0xff, 0x00, 0x00); // powered: red
    } else { // ZMK_USB_CONN_NONE
        status_pixels[persist_usb.position] = PERSIST_RGB(0x6b, 0x1f, 0xce); // disconnected: lilac
    }
}

// Unified status layer: indicators (if any), the persistent relocatable
// indicators (battery block + USB output), and the persistent per-pixel
// overrides set through the &pixel behavior. Runs regardless of whether any
// indicators are configured, so all of these show on every board.
static int zmk_led_generate_status(void) {
    int blend = zmk_led_generate_indicators();

    bool painted_persist = false;

    // Relocatable live indicators paint on top of any fixed indicators.
    if (persist_battery.active) {
        persist_paint_battery();
        painted_persist = true;
    }
    if (persist_usb.active) {
        persist_paint_usb();
        painted_persist = true;
    }

    // Fixed-color overrides win over everything (highest priority).
    if (any_pixel_override) {
        for (int i = 0; i < STRIP_NUM_PIXELS; i++) {
            if (pixel_override_active[i]) {
                status_pixels[i] = pixel_overrides[i];
            }
        }
        painted_persist = true;
    }

    // Anything persistent must show at full opacity, not faded by the
    // indicator fade-in/out envelope.
    if (painted_persist && blend < 256) {
        blend = 256;
    }

    return blend;
}

static inline struct led_rgb hue_sat(int hue, int sat) {
    struct zmk_led_hsb hsb = state.color;
    hsb.h = hue;
    hsb.s = sat;
    return hsb_to_rgb(hsb_scale_min_max(hsb));
}

static void zmk_rgb_underglow_tick(struct k_work *work) {
    switch (state.current_effect) {
    case UNDERGLOW_EFFECT_SOLID:
        zmk_rgb_underglow_effect_solid();
        break;
    case UNDERGLOW_EFFECT_BREATHE:
        zmk_rgb_underglow_effect_breathe();
        break;
    case UNDERGLOW_EFFECT_SPECTRUM:
        zmk_rgb_underglow_effect_spectrum();
        break;
    case UNDERGLOW_EFFECT_SWIRL:
        zmk_rgb_underglow_effect_swirl();
        break;
#if IS_ENABLED(UNDERGLOW_LAYER_ENABLED)
    case UNDERGLOW_EFFECT_LAYER_INDICATORS:
        zmk_rgb_underglow_effect_layer();
        break;
#endif
    }

    zmk_led_write_pixels();
}

K_WORK_DEFINE(underglow_tick_work, zmk_rgb_underglow_tick);

static void zmk_rgb_underglow_tick_handler(struct k_timer *timer) {
    if (!state.on) {
        return;
    }

    k_work_submit_to_queue(zmk_workqueue_lowprio_work_q(), &underglow_tick_work);
}

K_TIMER_DEFINE(underglow_tick, zmk_rgb_underglow_tick_handler, NULL);

#if IS_ENABLED(CONFIG_SETTINGS)
static int rgb_settings_set(const char *name, size_t len, settings_read_cb read_cb, void *cb_arg) {
    const char *next;
    int rc;

    if (settings_name_steq(name, "state", &next) && !next) {
        if (len != sizeof(state)) {
            return -EINVAL;
        }

        rc = read_cb(cb_arg, &state, sizeof(state));
        if (rc >= 0) {
            if (state.on) {
#if IS_ENABLED(UNDERGLOW_LAYER_ENABLED)
                if (state.layer_enabled) {
                    zmk_rgb_underglow_transient_on();
                    zmk_rgb_underglow_set_layer(rgb_underglow_top_layer(), true);
                }
#else
                k_timer_start(&underglow_tick, K_NO_WAIT, K_MSEC(50));
#endif
            }
            return 0;
        }

        return rc;
    }

    return -ENOENT;
}

SETTINGS_STATIC_HANDLER_DEFINE(rgb_underglow, "rgb/underglow", NULL, rgb_settings_set, NULL, NULL);

static void zmk_rgb_underglow_save_state_work(struct k_work *_work) {
    settings_save_one("rgb/underglow/state", &state, sizeof(state));
}

static struct k_work_delayable underglow_save_work;
#endif

static int zmk_rgb_underglow_init(void) {
    led_strip = DEVICE_DT_GET(STRIP_CHOSEN);

#if IS_ENABLED(CONFIG_ZMK_RGB_UNDERGLOW_EXT_POWER)
    if (!device_is_ready(ext_power)) {
        LOG_ERR("External power device \"%s\" is not ready", ext_power->name);
        return -ENODEV;
    }
#endif

    state = (struct rgb_underglow_state){
        color : {
            h : CONFIG_ZMK_RGB_UNDERGLOW_HUE_START,
            s : CONFIG_ZMK_RGB_UNDERGLOW_SAT_START,
            b : CONFIG_ZMK_RGB_UNDERGLOW_BRT_START,
        },
        animation_speed : CONFIG_ZMK_RGB_UNDERGLOW_SPD_START,
        current_effect : CONFIG_ZMK_RGB_UNDERGLOW_EFF_START,
        animation_step : 0,
        on : IS_ENABLED(CONFIG_ZMK_RGB_UNDERGLOW_ON_START),
        layer_enabled : false
    };

#if IS_ENABLED(CONFIG_SETTINGS)
    k_work_init_delayable(&underglow_save_work, zmk_rgb_underglow_save_state_work);
#endif

#if IS_ENABLED(CONFIG_ZMK_RGB_UNDERGLOW_AUTO_OFF_USB)
    state.on = zmk_usb_is_powered();
#endif

    if (state.on) {
        k_timer_start(&underglow_tick, K_NO_WAIT, K_MSEC(25));
    }
#if IS_ENABLED(UNDERGLOW_LAYER_ENABLED)
    if (state.layer_enabled) {
        zmk_rgb_underglow_set_layer(rgb_underglow_top_layer(), true);
    }
#endif
    return 0;
}

int zmk_rgb_underglow_save_state(void) {
#if IS_ENABLED(CONFIG_SETTINGS)
    int ret = k_work_reschedule(&underglow_save_work, K_MSEC(CONFIG_ZMK_SETTINGS_SAVE_DEBOUNCE));
    return MIN(ret, 0);
#else
    return 0;
#endif
}

int zmk_rgb_underglow_get_state(bool *on_off) {
    if (!led_strip)
        return -ENODEV;

    *on_off = state.on || state.layer_enabled;
    return 0;
}

void zmk_rgb_set_ext_power(void) {
    LOG_DBG("setting ext power");
#if IS_ENABLED(CONFIG_ZMK_RGB_UNDERGLOW_EXT_POWER)
    if (ext_power == NULL)
        return;
    int c_power = ext_power_get(ext_power);
    if (c_power < 0) {
        LOG_ERR("Unable to examine EXT_POWER: %d", c_power);
        c_power = 0;
    }
    int desired_state = state.on || state.status_active || any_pixel_override ||
                        any_persist_indicator();

#if IS_ENABLED(CONFIG_ZMK_BATTERY_REPORTING)
    // force power off, when battery low (<10%)
    if (state.on && !state.status_active) {
        if (zmk_battery_state_of_charge() < 10) {
            desired_state = false;
        }
    }
#endif // CONFIG_ZMK_BATTERY_REPORTING

    if (desired_state && !c_power) {
        int rc = ext_power_enable(ext_power);
        if (rc != 0) {
            LOG_ERR("Unable to enable EXT_POWER: %d", rc);
        }
    } else if (!desired_state && c_power) {
        int rc = ext_power_disable(ext_power);
        if (rc != 0) {
            LOG_ERR("Unable to disable EXT_POWER: %d", rc);
        }
    }
#endif // CONFIG_ZMK_RGB_UNDERGLOW_EXT_POWER
}

int zmk_rgb_underglow_on(void) {
#if IS_ENABLED(UNDERGLOW_LAYER_ENABLED)
    if (state.current_effect == UNDERGLOW_EFFECT_LAYER_INDICATORS) {
        state.layer_enabled = true;
    }
#endif
    zmk_rgb_underglow_transient_on();
    return zmk_rgb_underglow_save_state();
}

int zmk_rgb_underglow_transient_on(void) {
    if (!led_strip)
        return -ENODEV;

    state.on = true;
    zmk_rgb_set_ext_power();

    if (!state.layer_enabled) {
        state.animation_step = 0;
        k_timer_start(&underglow_tick, K_NO_WAIT, K_MSEC(25));
    }
    return 0;
}

static void zmk_rgb_underglow_off_handler(struct k_work *work) {
    for (int i = 0; i < STRIP_NUM_PIXELS; i++) {
        pixels[i] = (struct led_rgb){r : 0, g : 0, b : 0};
    }

    zmk_led_write_pixels();
}

K_WORK_DEFINE(underglow_off_work, zmk_rgb_underglow_off_handler);

int zmk_rgb_underglow_off(void) {
    zmk_rgb_underglow_transient_off();
    state.layer_enabled = false;
    return zmk_rgb_underglow_save_state();
}

int zmk_rgb_underglow_transient_off(void) {
    if (!led_strip)
        return -ENODEV;

    k_work_submit_to_queue(zmk_workqueue_lowprio_work_q(), &underglow_off_work);

    k_timer_stop(&underglow_tick);
    state.on = false;
    zmk_rgb_set_ext_power();

    return 0;
}

int zmk_rgb_underglow_calc_effect(int direction) {
    return (state.current_effect + UNDERGLOW_EFFECT_NUMBER + direction) % UNDERGLOW_EFFECT_NUMBER;
}

int zmk_rgb_underglow_select_effect(int effect) {
    if (!led_strip)
        return -ENODEV;

    if (effect < 0 || effect >= UNDERGLOW_EFFECT_NUMBER) {
        return -EINVAL;
    }

    state.current_effect = effect;
    state.animation_step = 0;
#if IS_ENABLED(UNDERGLOW_LAYER_ENABLED)
    state.layer_enabled = (effect == UNDERGLOW_EFFECT_LAYER_INDICATORS);
#endif
    return zmk_rgb_underglow_save_state();
}

int zmk_rgb_underglow_cycle_effect(int direction) {
    return zmk_rgb_underglow_select_effect(zmk_rgb_underglow_calc_effect(direction));
}

int zmk_rgb_underglow_toggle(void) {
    return state.on ? zmk_rgb_underglow_off() : zmk_rgb_underglow_on();
}

#if IS_ENABLED(UNDERGLOW_LAYER_ENABLED)

static struct led_rgb hex_to_rgb(uint8_t r, uint8_t g, uint8_t b) {
    struct zmk_led_hsb hsb = state.color;
    return (struct led_rgb){
        r : (hsb.b * (r)) / 0xff,
        g : (hsb.b * (g)) / 0xff,
        b : (hsb.b * (b)) / 0xff
    };
}

static int zmk_rgb_underglow_apply_merged_rgbmap() {
    LOG_DBG("applying merged rgbmap");
    int rc = 0;
    size_t len = 0;
    uint8_t active_layers[ZMK_KEYMAP_LAYERS_LEN];
    uint32_t layer_state = rgb_underglow_layers_state();
    LOG_DBG("layer state: %08x", layer_state);
    for (uint8_t layer = ZMK_KEYMAP_LAYERS_LEN - 1; layer > 0; layer--) {
        if ((layer_state & (BIT(layer))) == (BIT(layer)) || layer == 0) {
            active_layers[len] = layer;
            len++;
            LOG_DBG("active layer: %d", layer);
        }
    }
    active_layers[len++] = 0; // add default layer (0)
    // fast track if no bindings on top layer
    if (rgb_underglow_get_bindings(active_layers[0]) == NULL) {
        LOG_DBG("no rgb bindings found for active layer: %d", active_layers[0]);
        return 0;
    }

    for (int pixel = 0; pixel < STRIP_NUM_PIXELS; pixel++) {
        uint8_t midx = rgb_pixel_lookup(pixel);
        int color = 0;
        if (midx >= ZMK_KEYMAP_LEN) {
            LOG_DBG("out of range");
        } else {

            for (int layer = 0; layer < len; layer++) {
                // LOG_DBG("getting rgb bindings for active layer: %d", active_layers[layer]);
                const struct zmk_behavior_binding *bindings =
                    rgb_underglow_get_bindings(active_layers[layer]);
                if (bindings != NULL) {
                    const struct device *dev =
                        zmk_behavior_get_binding(bindings[midx].behavior_dev);
                    if (dev != NULL) {
                        const struct behavior_driver_api *api =
                            (const struct behavior_driver_api *)dev->api;
                        if (api->binding_pressed != NULL) {
                            struct zmk_behavior_binding_event event = {.position = midx,
                                                                       .layer =
                                                                           active_layers[layer],
                                                                       .timestamp = k_uptime_get()};

                            color = api->binding_pressed(
                                (struct zmk_behavior_binding *)&bindings[midx], event);
                            if (color == ZMK_BEHAVIOR_TRANSPARENT) {
                                color = 0;
                                continue;
                            }
                        } // end if binding_pressed != NULL
                    } // end if dev != NULL
                } // end if bindings != NULL

                break;
            } // end for each active layer

            // set pixel color
            pixels[pixel] =
                hex_to_rgb((color & 0xFF0000) >> 16, (color & 0xFF00) >> 8, color & 0xFF);

            if (color > 0) {
                rc = 1; // layer has at least one pixel up
            }
        } // end for each pixel
    }
    return rc;
}

static int zmk_rgb_underglow_apply_rgbmap(const struct zmk_behavior_binding *bindings,
                                          size_t rgbmap_len, uint8_t layer) {
    LOG_DBG("applying rgbmap for layer: %d", layer);
    return zmk_rgb_underglow_apply_merged_rgbmap();
    int rc = 0;
    for (int i = 0; i < STRIP_NUM_PIXELS; i++) {
        uint8_t midx = rgb_pixel_lookup(i);
        if (midx >= ZMK_KEYMAP_LEN) {
            LOG_DBG("out of range");
        } else {
            const struct device *dev = zmk_behavior_get_binding(bindings[midx].behavior_dev);

            if (dev == NULL) {
                continue;
            }

            const struct behavior_driver_api *api = (const struct behavior_driver_api *)dev->api;

            if (api->binding_pressed == NULL) {
                continue;
            }
            struct zmk_behavior_binding_event event = {
                .position = midx, .layer = layer, .timestamp = k_uptime_get()};

            int color = api->binding_pressed((struct zmk_behavior_binding *)&bindings[midx], event);

            if (color > 0) {
                pixels[i] =
                    hex_to_rgb((color & 0xFF0000) >> 16, (color & 0xFF00) >> 8, color & 0xFF);
                rc = 1;
            } else {
                pixels[i] = (struct led_rgb){r : 0, g : 0, b : 0};
            }
        }
    }
    return rc;
}

static void zmk_rgb_underglow_set_layer(uint8_t layer, bool wakeup) {
    LOG_DBG("state.layer: %d state.on: %d", state.layer_enabled, state.on);
    if (!state.layer_enabled)
        return;

    if (zmk_rgb_underglow_apply_merged_rgbmap()) {
        if (!state.on) {
            if (!wakeup) {
                LOG_DBG("rgb off and no wakeup, abort refresh");
                return;
            }
            zmk_rgb_underglow_transient_on();
        }
        k_timer_stop(&underglow_tick);
        state.animation_step = 0;
        int fade_delay = zmk_rgbmap_fade_delay(layer);
        if (fade_delay >= 0) {
            k_timer_start(&underglow_tick, K_SECONDS(fade_delay), K_MSEC(50));
        }
        LOG_DBG("write pixels");
        zmk_led_write_pixels();
    } else {
        if (state.on)
            zmk_rgb_underglow_transient_off();
    }
}
#endif /* IS_ENABLED(UNDERGLOW_LAYER_ENABLED) */

static void zmk_led_write_pixels_work(struct k_work *work);
static void zmk_rgb_underglow_status_update(struct k_timer *timer);

K_WORK_DEFINE(underglow_write_work, zmk_led_write_pixels_work);
K_TIMER_DEFINE(underglow_status_update_timer, zmk_rgb_underglow_status_update, NULL);

static void zmk_rgb_underglow_status_update(struct k_timer *timer) {
    bool persist = any_persist_indicator();

    if (!state.status_active && !persist) {
        k_timer_stop(&underglow_status_update_timer);
        return;
    }

    if (state.status_active) {
        state.status_animation_step++;
        if (state.status_animation_step > (10000 / 25)) {
            state.status_active = false;
            // Don't stop the timer if persistent indicators still need refreshing.
            if (!persist)
                k_timer_stop(&underglow_status_update_timer);
        }
    }
    if (!k_work_is_pending(&underglow_write_work))
        k_work_submit(&underglow_write_work);
}

static void zmk_led_write_pixels_work(struct k_work *work) {
    zmk_led_write_pixels();
    if (!state.status_active) {
        zmk_rgb_set_ext_power();
    }
}

int zmk_rgb_underglow_status(void) {
    if (!state.status_active) {
        state.status_animation_step = 0;
    } else {
        if (state.status_animation_step > (500 / 25)) {
            state.status_animation_step = 500 / 25;
        }
    }
    state.status_active = true;
    zmk_led_write_pixels();
    zmk_rgb_set_ext_power();

    k_timer_start(&underglow_status_update_timer, K_NO_WAIT, K_MSEC(25));

    return 0;
}

int zmk_rgb_underglow_set_pixel(uint32_t position, int32_t color) {
    if (!led_strip)
        return -ENODEV;

    if (position >= STRIP_NUM_PIXELS) {
        LOG_WRN("pixel override position %u out of range (strip is %d pixels, local half only)",
                position, STRIP_NUM_PIXELS);
        return -EINVAL;
    }

    if (color < 0) {
        // Clear this override.
        if (pixel_override_active[position]) {
            pixel_override_active[position] = false;
            pixel_overrides[position] = (struct led_rgb){r : 0, g : 0, b : 0};
        }
    } else {
        uint8_t r = (color & 0xFF0000) >> 16;
        uint8_t g = (color & 0x00FF00) >> 8;
        uint8_t b = (color & 0x0000FF);
        pixel_overrides[position] = (struct led_rgb){
            r : (CONFIG_ZMK_RGB_UNDERGLOW_BRT_MAX * r) / 0xff,
            g : (CONFIG_ZMK_RGB_UNDERGLOW_BRT_MAX * g) / 0xff,
            b : (CONFIG_ZMK_RGB_UNDERGLOW_BRT_MAX * b) / 0xff
        };
        pixel_override_active[position] = true;
    }

    // Recompute the "any override" flag.
    any_pixel_override = false;
    for (int i = 0; i < STRIP_NUM_PIXELS; i++) {
        if (pixel_override_active[i]) {
            any_pixel_override = true;
            break;
        }
    }

    // Make sure power is available and push the new buffer to the strip now,
    // even if underglow is currently off.
    zmk_rgb_set_ext_power();
    zmk_led_write_pixels();

    return 0;
}

int zmk_rgb_underglow_clear_pixels(void) {
    if (!led_strip)
        return -ENODEV;

    memset(pixel_overrides, 0, sizeof(pixel_overrides));
    memset(pixel_override_active, 0, sizeof(pixel_override_active));
    any_pixel_override = false;

    zmk_led_write_pixels();
    zmk_rgb_set_ext_power();

    return 0;
}

uint8_t zmk_rgb_underglow_pixel_count(void) { return STRIP_NUM_PIXELS; }

// Ensure the status-update timer is running so persistent indicators refresh
// (and get an immediate first paint), then push the current frame now.
static void persist_indicator_kick(void) {
    zmk_rgb_set_ext_power();
    zmk_led_write_pixels();
    k_timer_start(&underglow_status_update_timer, K_NO_WAIT, K_MSEC(25));
}

int zmk_rgb_underglow_set_battery_indicator(const uint8_t *positions, uint8_t count) {
    if (!led_strip)
        return -ENODEV;

    if (count == 0 || positions == NULL) {
        // Disable.
        persist_battery.active = false;
        persist_battery.count = 0;
        persist_indicator_kick();
        return 0;
    }

    if (count > PERSIST_BAT_MAX_PIXELS) {
        LOG_WRN("battery indicator: %u positions requested, clamping to %d", count,
                PERSIST_BAT_MAX_PIXELS);
        count = PERSIST_BAT_MAX_PIXELS;
    }

    for (uint8_t i = 0; i < count; i++) {
        if (positions[i] >= STRIP_NUM_PIXELS) {
            LOG_WRN("battery indicator position %u out of range (strip is %d, local half only)",
                    positions[i], STRIP_NUM_PIXELS);
        }
        persist_battery.positions[i] = positions[i];
    }
    persist_battery.count = count;
    persist_battery.active = true;

    persist_indicator_kick();
    return 0;
}

int zmk_rgb_underglow_clear_battery_indicator(void) {
    return zmk_rgb_underglow_set_battery_indicator(NULL, 0);
}

int zmk_rgb_underglow_set_usb_indicator(uint32_t position) {
    if (!led_strip)
        return -ENODEV;

    if (position >= STRIP_NUM_PIXELS) {
        LOG_WRN("usb indicator position %u out of range (strip is %d, local half only)", position,
                STRIP_NUM_PIXELS);
        return -EINVAL;
    }

    persist_usb.position = position;
    persist_usb.active = true;

    persist_indicator_kick();
    return 0;
}

int zmk_rgb_underglow_clear_usb_indicator(void) {
    if (!led_strip)
        return -ENODEV;

    persist_usb.active = false;
    persist_indicator_kick();
    return 0;
}

int zmk_rgb_underglow_set_hsb(struct zmk_led_hsb color) {
    if (color.h > HUE_MAX || color.s > SAT_MAX || color.b > BRT_MAX) {
        return -ENOTSUP;
    }

    state.color = color;

    return 0;
}

struct zmk_led_hsb zmk_rgb_underglow_calc_hue(int direction) {
    struct zmk_led_hsb color = state.color;

    color.h += HUE_MAX + (direction * CONFIG_ZMK_RGB_UNDERGLOW_HUE_STEP);
    color.h %= HUE_MAX;

    return color;
}

struct zmk_led_hsb zmk_rgb_underglow_calc_sat(int direction) {
    struct zmk_led_hsb color = state.color;

    int s = color.s + (direction * CONFIG_ZMK_RGB_UNDERGLOW_SAT_STEP);
    if (s < 0) {
        s = 0;
    } else if (s > SAT_MAX) {
        s = SAT_MAX;
    }
    color.s = s;

    return color;
}

struct zmk_led_hsb zmk_rgb_underglow_calc_brt(int direction) {
    struct zmk_led_hsb color = state.color;

    int b = color.b + (direction * CONFIG_ZMK_RGB_UNDERGLOW_BRT_STEP);
    color.b = CLAMP(b, 0, BRT_MAX);

    return color;
}

int zmk_rgb_underglow_change_hue(int direction) {
    if (!led_strip)
        return -ENODEV;

    state.color = zmk_rgb_underglow_calc_hue(direction);

    return zmk_rgb_underglow_save_state();
}

int zmk_rgb_underglow_change_sat(int direction) {
    if (!led_strip)
        return -ENODEV;

    state.color = zmk_rgb_underglow_calc_sat(direction);

    return zmk_rgb_underglow_save_state();
}

int zmk_rgb_underglow_change_brt(int direction) {
    if (!led_strip)
        return -ENODEV;

    state.color = zmk_rgb_underglow_calc_brt(direction);

    return zmk_rgb_underglow_save_state();
}

int zmk_rgb_underglow_change_spd(int direction) {
    if (!led_strip)
        return -ENODEV;

    if (state.animation_speed == 1 && direction < 0) {
        return 0;
    }

    state.animation_speed += direction;

    if (state.animation_speed > 5) {
        state.animation_speed = 5;
    }

    return zmk_rgb_underglow_save_state();
}

#if IS_ENABLED(CONFIG_ZMK_RGB_UNDERGLOW_AUTO_OFF_IDLE) ||                                          \
    IS_ENABLED(CONFIG_ZMK_RGB_UNDERGLOW_AUTO_OFF_USB) || IS_ENABLED(UNDERGLOW_LAYER_ENABLED)
struct rgb_underglow_sleep_state {
    bool is_awake;
    bool rgb_state_before_sleeping;
};

static int rgb_underglow_auto_state(bool target_wake_state) {
    static struct rgb_underglow_sleep_state sleep_state = {
        is_awake : true,
        rgb_state_before_sleeping : false
    };

    // wake up event while awake, or sleep event while sleeping -> no-op
    if (target_wake_state == sleep_state.is_awake) {
        return 0;
    }
    sleep_state.is_awake = target_wake_state;

    if (sleep_state.is_awake) {
#if IS_ENABLED(UNDERGLOW_LAYER_ENABLED)
        if (state.layer_enabled) {
            zmk_rgb_underglow_set_layer(rgb_underglow_top_layer(), true);
            return 0;
        }
#endif
        if (sleep_state.rgb_state_before_sleeping) {
            return zmk_rgb_underglow_transient_on();
        } else {
            return zmk_rgb_underglow_transient_off();
        }
    } else {
        sleep_state.rgb_state_before_sleeping = state.on;
        return zmk_rgb_underglow_transient_off();
    }
}

static int rgb_underglow_event_listener(const zmk_event_t *eh) {

#if IS_ENABLED(CONFIG_ZMK_RGB_UNDERGLOW_AUTO_OFF_IDLE)
    if (as_zmk_activity_state_changed(eh)) {
        return rgb_underglow_auto_state(zmk_activity_get_state() == ZMK_ACTIVITY_ACTIVE);
    }
#endif

#if IS_ENABLED(UNDERGLOW_LAYER_ENABLED)
    if (as_zmk_split_peripheral_layer_changed(eh)) {
        const struct zmk_split_peripheral_layer_changed *ev =
            as_zmk_split_peripheral_layer_changed(eh);
        LOG_DBG("zmk_split_peripheral_layer_changed: %08x", ev->layers);
#if !IS_ENABLED(CONFIG_ZMK_SPLIT_ROLE_CENTRAL)
        set_peripheral_layers_state(ev->layers);
#endif
        uint8_t layer = rgb_underglow_top_layer();
        LOG_DBG("top layer: %d", layer);
        zmk_rgb_underglow_set_layer(layer, true);
        return 0;
    }
    if (as_zmk_underglow_color_changed(eh)) {
        const struct zmk_underglow_color_changed *ev = as_zmk_underglow_color_changed(eh);
        uint8_t layer = rgb_underglow_top_layer();
        LOG_DBG("refresh layers %d, current: %d, wakeup: %d", ev->layers, layer, ev->wakeup);
        if ((ev->layers & (BIT(layer))) == BIT(layer)) {
            zmk_rgb_underglow_set_layer(rgb_underglow_top_layer(), ev->wakeup);
        }
        return 0;
    }
#endif /* UNDERGLOW_LAYER_ENABLED */

#if IS_ENABLED(CONFIG_ZMK_RGB_UNDERGLOW_AUTO_OFF_USB)
    if (as_zmk_usb_conn_state_changed(eh)) {
        return rgb_underglow_auto_state(zmk_usb_is_powered());
    }
#endif

    return -ENOTSUP;
}

ZMK_LISTENER(rgb_underglow, rgb_underglow_event_listener);
#endif // IS_ENABLED(CONFIG_ZMK_RGB_UNDERGLOW_AUTO_OFF_IDLE) ||
       // IS_ENABLED(CONFIG_ZMK_RGB_UNDERGLOW_AUTO_OFF_USB) ||
       // IS_ENABLED(UNDERGLOW_LAYER_ENABLED)

#if IS_ENABLED(CONFIG_ZMK_RGB_UNDERGLOW_AUTO_OFF_IDLE)
ZMK_SUBSCRIPTION(rgb_underglow, zmk_activity_state_changed);
#endif

#if IS_ENABLED(CONFIG_ZMK_RGB_UNDERGLOW_AUTO_OFF_USB)
ZMK_SUBSCRIPTION(rgb_underglow, zmk_usb_conn_state_changed);
#endif

#if IS_ENABLED(UNDERGLOW_LAYER_ENABLED)
ZMK_SUBSCRIPTION(rgb_underglow, zmk_split_peripheral_layer_changed);
ZMK_SUBSCRIPTION(rgb_underglow, zmk_underglow_color_changed);
#endif

SYS_INIT(zmk_rgb_underglow_init, APPLICATION, CONFIG_APPLICATION_INIT_PRIORITY);
